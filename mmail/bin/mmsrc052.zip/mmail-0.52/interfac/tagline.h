/* Perhaps these don't deserve to be enshrined in the source code, but I
wanted to simplify installation by having the tagline file auto-generated
for new users. You can replace this list with whatever taglines you like
(just make sure the last item is a zero). - WJM3 */

#ifndef TAGLINES_H
#define TAGLINES_H

static const char *defaultTags[] = {
 "MultiMail, the new multi-platform, multi-format offline reader!",
 "\"42? 7 and a half million years and all you can come up with is 42?!\"",
 "2 + 2 = 5 for extremely large values of 2.",
 "Computer Hacker wanted. Must have own axe.",
 "DalekDOS v(overflow): (I)Obey (V)ision impaired (E)xterminate",
 "Direct from the Ministry of Silly Walks",
 "Gone crazy, be back later, please leave message.",
 "Got my tie caught in the fax... Suddenly I was in L.A.",
 "He does the work of 3 Men...Moe, Larry & Curly",
 "Heisenberg may have slept here.",
 "Internal Error: The system has been taken over by sheep at line 19960",
 "So easy, a child could do it. Child sold separately.",
 "The number you have dailed...Nine-one-one...has been changed.",
 "What is mind? No matter! What is matter? Never mind! - Homer S.",
 0
};

#endif
