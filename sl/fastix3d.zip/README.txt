                                Fast Index
                Faster Nodelist Index Builder for Searchlight
                             version 3.0, 3.0a
                          http://wmcbrine.com/sl/

                         Copyright (c) 1996, 1999
                    William McBrine <wmcbrine@gmail.com>
                             and Martin Coyne


:::: INTRODUCTION ::::

Fast Index is a drop-in replacement for Searchlight's INDEX.EXE.  From raw
nodelists, it builds NLINDEX.SL2 files identical (or nearly so -- see
below) to those made by INDEX, but it works much faster.  Performance
varies, from a low of about five times as fast to a measured high of one
hundred times the speed.

There's also a serious bug in INDEX 4.0+, such that it frequently
transposes two entries in the sorted-by-name half of the nodelist index.  
This leaves some names unreachable when searching the index -- effectively
dropping them from the list.  Fast Index will sort the names correctly.

The following assumes that you've read the Nodelist Index section of your
Searchlight manual (on page 205 in the 4.5 manual).  You do NOT need to
run INDEX before using Fast Index, but you must read its documentation.


:::: LICENSE AGREEMENT ::::

This program is free software, now released under the GPL.  See "COPYING"  
for terms.


:::: INSTALLATION AND OPERATION ::::

To install this program, simply copy the appropriate executable to the
same directory as INDEX.EXE, and change "index" to the appropriate
filename in any batch file which calls INDEX.  There are four executables
included in the package; see below for an explanation.

Fast Index operates just like INDEX, and accepts the same command-line
parameters.  Nodelists are set up with CONFIG; you can force a recompile
with the "F" parameter, or exclude zones by using them as parameters.  Up
to ten zones may be excluded.  Each parameter may be prefaced with "-",
"/" or nothing; "fastidx -f", "fastidx /f", and "fastidx f" would all
force recompilation.

Errorlevels returned by Fast Index are:

 0 - Everything went OK OR index didn't need updating OR NLINDEX.SL2
     hasn't been set up in CONFIG.
 1 - Not enough memory.
 3 - Error writing to disk (probably not enough room).
 4 - Too many nets.
 5 - Too many nodes in a given net.

Error 2 - "One of the nodelists defined in NLINDEX.SL2 doesn't exist" -
has been discontinued.  A warning message is given instead, and Fast Index
continues with any remaining nodelists.  This is more like the behavior of
INDEX, which skips nodelists it can't find (but gives no warning).

For more information, please refer to the Nodelist Index section of your
Searchlight manual.


:::: WHICH EXECUTABLE? ::::

In this archive, I've combined the original 3.0 executables (16-bit DOS
and 32-bit OS/2) with the 3.0a executables (32-bit DOS and Windows) that
were released separately a few years later.  (Thus, this archive can
replace all three of the previous ones.)

*** FASTIDX.EXE ***

The original 16-bit MS-DOS version.  It will run almost anywhere, but
you'll get better performance from one of the 32-bit versions if your
system supports it.  Compiled with Borland Pascal.

*** FASTOS2.EXE ***

The first of the 32-bit ports, for OS/2 2.0 or later.  About twice as fast
as the 16-bit version.  Compiled with Virtual Pascal.

*** FAST386.EXE ***

A DPMI (DOS Protected Mode Interface) client, with a built-in DPMI server
(PMODE/DJ) if needed.  It requires at least a 386 and 3 megs of RAM.

Although it has a different version number ("3.0a"), it's a straight port
of the OS/2 Virtual Pascal version of Fast Index 3.0, with only the very
minimal changes required for Free Pascal (aka "FPC").  It offers the same
performance advantages as fastos2.exe.  The biggest code change is in the
opening banner. :-)  fast386.exe has been tested successfully under OS/2,
Win 95, and Linux's DOSEmu.

*** FASTW32.EXE ***

The Win32 console version of the Free Pascal port of Fast Index.  It
should work on Windows 9x, ME, NT, 2000 and XP (only tested on 95).

*** Other port status ***

I have a Linux version that works well, except that it doesn't understand
the MS-DOS-style pathnames which are typically embedded in nlindex.sl2.
I can code around this if there's interest (I may do it anyway).  The
Linux version was actually the first FPC-based port I did -- and no
further changes were then needed to port it (back) to MS-DOS.


:::: PERFORMANCE AND LIMITATIONS ::::

It appears that INDEX is I/O-bound, while Fast Index is more CPU-bound.
The presence or absence of a cache makes little difference to Fast Index,
but more free (conventional) memory will help it.  On a machine with a
slow CPU, it may appear to stop for a while as it sorts in memory.  Don't
worry -- it's still going.

Fast Index uses more system resources than INDEX.  Where INDEX needs 24
bytes per node in the nodelist of free disk space, Fast Index needs 62.  
It requires 256k free memory, plus the amount needed to hold all entries
for the letter of the alphabet with which the most sysop names begin.  
(Yes, I know that sounds strange.)  In the case of the Fidonet nodelist,
this is the letter J.  Over 3000 sysop names begin with J; that's 3000 *
40 bytes per entry + 192k (64k from the first 256k is reused), or about
309k.  With 592k free, you could have up to 10240 nodes per letter; with
only 400k, you'd be limited to 5324.

The 32-bit versions require 256k more to start with (512k total), of which
192k (rather than 64k) will be reused, and they will grab up to 2 megs of
RAM in an attempt to sort everything in one pass.  Each entry takes up 38
bytes rather than 40.

If Fast Index runs out of memory, it estimates and reports the additional
amount required.

Fast Index has some limitations which may not be present in INDEX.  The
maximum total number of nets is 6552 (maybe seven times the size of the
current Fidonet nodelist), or 19656 with the 32-bit versions.  Nodes per
net are limited to 1724, or 5172 in 32-bit versions (there's one extremely
large net in Fidonet with over 500 nodes, but the average is about 42
nodes per net).  Nodes per letter of the alphabet are limited to 16380
(49140 in the 32-bit versions), but memory requirements restrict that
further, as described above.  These limits apply to all nodelists added
together.  Since no othernet comes close to the size of Fidonet, this
shouldn't be a problem yet.

Here are the results of some tests showing the difference in compile times
(expressed in minutes:seconds) for different versions of Fast Index and
INDEX.  In each case, I compiled only Fidonet's NODELIST.363:

 Machine 1               33mhz (turbo on)      8mhz (turbo off)
 ---------               ----------------      ----------------
 INDEX v3.0                   9:07                   --
 INDEX v4.0a                 12:57                   --
 FASTIDX v2.3                 1:05                  5:50
 FASTIDX v2.4                 0:50                  4:20
 FASTOS2 v2.4                 0:41                  3:23
 FASTIDX v3.0                 0:41                  3:23
 FASTOS2 v3.0                 0:18                  1:20

 Machine 2       50mhz (DOS)   ??mhz (DOS)   50mhz (Win)   ??mhz (Win)
 ---------       -----------   -----------   -----------   -----------
 INDEX v3.0          5:55         14:20          5:30         10:42
 INDEX v4.0a        11:04         38:22          7:02         17:23
 FASTIDX v2.4        0:38          1:47          0:33          1:42
 FASTIDX v3.0        0:29          1:16          0:22          1:09

Machine 1 is a '92 486dx33 ISA system, 8 megs, running a new 850 meg drive
off IDE, formatted HPFS, under OS/2 3.0.

Machine 2 is a '94 486dx/2-50 VL/ISA system, 8 megs, running a 424 meg
drive off VL-IDE, formatted FAT.  The "DOS" times were taken under DOS
6.2, using SmartDrv with a 2 meg buffer; the "Win" times were under
Windows for Workgroups 3.11, using 32-bit file access.  "??mhz" means the
turbo button was off, though I couldn't identify this with a specific
speed.  (According to the manual, turning off turbo disables the cache.)

Perhaps the most interesting datum is the degradation in performance from
INDEX 3.0 to INDEX 4.0a.  My impression is that changes were made to 4.0a
in an attempt to boost its performance, but it backfired, compromising
both speed and accuracy.

Update, 1999: "Machine 1" has since been upgraded to a 486DX4/100 with 64
megs of RAM, running Linux.  Under DOSEmu, compiling a recent nodelist of
20,000 nodes, fast386.exe comes in at just over four seconds, vs. almost
eleven seconds for fastidx.exe.  Wow, you can save seven seconds! :-)
With equipment that no longer even qualifies as modern, we've obviously
reached the point of diminishing returns.


:::: BACKGROUND ::::

For me (William McBrine), this project began when I needed to parse the
nodelist index in Valence, my QWK door.  When Searchlight Software added
netmail capability to SL, they didn't publish code to access NLINDEX.SL2,
nor a description of its format; and inquiries about it weren't answered.
So, I reverse-engineered it.  When I mentioned this in an echo, I got a
reply from Martin Coyne asking for the format.  He said he wanted to write
a faster index program.  He also said that Frank LaRosa told him that "the
program was optimized for speed and that it was unlikely that a faster one
be written."  With that direct challenge, I offered to collaborate on an
improved index program.

The resulting program is mostly mine, but it wouldn't exist without
Martin. He supplied the impetus, and contributed nodelist-parsing code
(Netstats) and sorting routines.


:::: NLINDEX.SL2 - WHAT IT IS ::::

The format of the Searchlight nodelist index, as I've worked it out
(expressed in Borland Pascal structrues):

The first 12 bytes are a record of type FileHeader, as defined in
BLOCK.REF in the Searchlight Programmer's Library.  (Nearly all the
Searchlight data files are of this type.)  The values for NLINDEX.SL2 are
constant:

 record
   version: word = 10;
   recsize: word = 12;
   offset: longint = {248 for Searchlight below 4.0; 1423 for SL 4.0+};
   nextfree: longint = 0
 end;

The version number is meaningless, and the nextfree pointer is not used in
this file.  The recsize and offset tell us that all of the file past the
first 248 or 1423 bytes is made up of 12-byte records.

Next is the list of raw nodelists.

 array[1..numlists] of record
                         name: string[40];
                         ext: string[3];
                         zone: word
                       end;

where numlists = (offset - 13) / 47.  Versions of Searchlight prior to 4.0
set this to 5; 4.0 and later use 30.  (Although the Searchlight 4.0+
CONFIG program only lets you enter 20 nodelist names, space for 30 is
reserved in the file.)

"Name" is what you type in CONFIG:  the full pathname of the raw nodelist,
minus the extension.  (If you do type in the extension, it'll be ignored.)
"Ext" is the extension that nodelist had on last compilation.  When run,
the index program compares this to the current extension.  If all the
extensions are the same, it considers the index up to date; otherwise it
recompiles the whole thing (the structure doesn't lend itself to
incremental compilation). "Zone" is the highest zone number found in a
given list during compilation. As far as I know, this value isn't used for
anything.  (At first I thought it might be used to tell which raw nodelist
a given node came from, but then I learned that's stored explicitly in
each record.)

That's 47 * numlist = 235 or 1410 bytes, plus the intial 12 = 247 or 1422.
There's one more byte before the node records begin.  It appears to be

 compiled: boolean;

It's 0 when the file is first created by CONFIG, and 1 thereafter.

The rest of the file consists of a very large number of records of this
type:

 record
   listnum: shortint;
   zone, net, node: word;
   length: byte;
   offset: longint
 end;

There are two complete lists, with each node listed twice.  The first list
is sorted by zone:net/node, and the second is sorted by sysop name.
"Listnum" is the number of the raw nodelist (an index to the array at the
beginning of NLINDEX.SL2) a node came from, if in the first list, or the
negative of that number in the second.  "Length" is the length in bytes of
the original entry in the raw nodelist, from the third field (system name)
on, and "offset" is the offset to that entry (at the third field).

To search the nodelist, first, decide if you want to use the node-ordered
or name-ordered list.  Take the size in records ((filesize-offset)/12),
divide it by two, and divide it by two again to put yourself midway
through the appropriate list (either 1/4th or 3/4th of the way through the
file).  Read the record there and compare it to your target.  (If you're
using the second list, read "length" bytes from "offset" in raw nodelist
#listnum, skip over the system name and location fields, uppercase and
turn underbars to spaces, and compare THAT to the name you're looking
for.)  If your target is higher, jump halfway towards the end of the list;
if lower, towards the beginning. Halve the interval and repeat until
found, or until you've found it's not there.


:::: SOURCE NOTES ::::

Fast Index is written in Pascal, with some assembly.  It does NOT use the
Searchlight Programmer's Library.

You can see some of my bad old habits in this code -- I used to include
very little white space, for example, which makes it difficult to read.
(I do almost the opposite nowadays.)  I wouldn't write this way now, but I 
decided to leave it as it was for its historical interest.  I rarely use 
assembly, either, since the sort of things I found it necessary for in 
Pascal are handled gracefully by C.

fastix32.pas is the source for both fast386.exe and fastw32.exe, and could
also be used to compile on several other platforms with FPC.  I haven't 
tried to compile it in quite a while, though.  fastidx.pas is the 16-bit 
version, and fastos2.pas is for Virtual Pascal under OS/2.


:::: ACKNOWLEDGEMENTS ::::

The routines to parse the raw nodelist were originally dervied from the
public domain program NetStats by Justin Marquez, sysop at 1:106/100.  
The sort routines are based in part on code from the SourceWare Archival
Group.

Free Pascal (aka FPC, aka FPK):

 http://www.freepascal.org/

PMODE/DJ:

 http://www.delorie.com/djgpp/


:::: HISTORY ::::

 3.0d  4/28/14   Updated addresses again; minor doc changes.

 3.0c  1/14/05   Updated addresses yet again.

 3.0b  6/13/03   Updated addresses again (argh); minor changes to the
                 documentation.

 3.0a 12/23/02   Consolidated 3.0 and 3.0a archives, updated Internet
                 addresses, changed ".doc" file extensions to ".txt";
                 changed license; released source.

       8/29/99   32-bit Windows console version.

       8/19/99   32-bit MS-DOS version, compiled with Free Pascal.
                 (Equivalent to OS/2 version. No other changes.)

 3.0   2/09/96   Second Anniversary Edition. :-)

                 Sorting routines changed from Comb sort to Quick sort
                 for a major speedup. Plus other, minor changes for
                 efficiency.

                 OS/2 version now uses more memory for faster compiling.
                 It's now signifigantly different from the DOS version
                 (and over twice as fast on my system), taking advantage
                 of the flat address space.

                 Previously, Fast Index required NLINDEX.SL2 to be in
                 the current directory. Now, if it's not there, it can
                 find it via CONFIG.SL2, as INDEX does.

                 Instead of aborting on not-found nodelists, Fast Index
                 will now compile any it does find, with only a warning
                 message. This is more like INDEX (which skips not-found
                 nodelists, but doesn't give a warning).

                 NLINDEX.SL2 now opened in Shared mode, as INDEX does.

                 In prior versions, Fast Index could go into an infinite
                 loop if it found at least one node, but no nets or
                 zones. (Once again, revealed by the DBNET nodelist.)

                 Another change for the sake of the DBNET nodelist:
                 unrecognized keywords now treated as standard nodes.

 2.4   1/05/96   A minor change in the sorting routine producing an
                 approximately 20% speedup.

                 32-bit OS/2 version included (about 20% faster yet),
                 compiled with Virtual Pascal.

                 In earlier versions, the keywords (e.g. "Zone",
                 "Region") were handled case-sensitively. This worked
                 with most nodelists, but not all (e.g., DBNET).

                 I noticed Fast Index's output was no longer identical
                 to INDEX's, byte-for-byte, as it was when I first wrote
                 it. This is due to a bug in INDEX 4.0+, not in Fast
                 Index (see FASTIDX.DOC).

 2.3   6/30/95   Minor changes to allow recompilation under OS/2;
                 should also speed things up slightly in DOS.

 2.2  12/09/94   Should no longer choke on badly-formed nodelists.

                 Tiny changes for extra efficiency. Recompiled with
                 Turbo Pascal 7.0.

                 Documentation revised. Note new address.

 2.1   6/13/94   With 2.0, I got "Nodelist   not found" reports from
                 some using Searchlight 4.0. When Searchlight upgrades
                 the list of nodelists, it zeroes out the new space, but
                 leaves a 1 in what used to be the "compiled:boolean"
                 flag. This becomes the length byte in the name of a
                 spurious sixth entry. INDEX still works, because when
                 it can't find a nodelist, it just skips it; but Fast
                 Index sees an error in the configuration and aborts.
                 (As of 3.0, Fast Index works the same as INDEX in this
                 respect. Fast Index 1.0 *appears* to work, because it
                 never reads the sixth entry, but the NLINDEX.SL2 it
                 compiles is incompatible with Searchlight 4.0.) Fast
                 Index 2.1 will ignore (and zero out) any entry where
                 the pathname is less than five characters total.

                 Also now checks that the first character of the
                 extension is a number. (It used to check the last
                 character.) This should prevent it from trying to
                 compile compressed nodelists.

 2.0   5/23/94   With NLINDEX.SL2 extended to allow up to 30 nodelists,
                 Searchlight 4.0 broke Fast Index 1.0. Now it works with
                 either the old or new structure automatically, and can
                 handle from 1 to 127 entries.

 1.0   2/09/94   First release.
