             Member Purge, Member List, Mail Purge, Mail List and
                      ALIAS.SL2 Builder for Searchlight
                           http://wmcbrine.com/sl/

                         Copyright (c) 1994 - 1999
                    William McBrine <wmcbrine@gmail.com>

             Written using the Searchlight Programmer's Library
              Portions Copyright (c) 1994 Searchlight Software


:::: SLMISC ::::

This is a new distribution of my several smaller Searchlight utility
programs, previously distributed as MEMBUT21.ZIP, MAILUTIL.ZIP, and
ALIASBLD.ZIP. The only real difference from the previous packages is that
Member List has been modified to use four-digit dates.


:::: MEMBLIST.EXE ::::

This program lists every member in every subboard except MAIL and
BULLETINS, along with last message read and date of last access. It was
originally intended to show how much each subboard was being used.

Some message statistic programs use the number-of-times-read fields; these
aren't good indicators because they aren't always incremented. (By default,
Valence doesn't.) The date of last access, as shown by Member List, isn't
always accurate, either. (Early versions of Valence didn't update it, nor
do several other programs.) The last message read is the most reliable way
to gauge subboard use.

Member List is also useful in conjunction with Member Purge.

Version 1.1 uses 4-digit years in its displayed dates, when used with the
appropriate version of Searchlight (5.0 or later).


:::: MEMBPURG.EXE ::::

This is an updated version of the program formerly called JUNKPURG.EXE,
which was distributed with Valence 1.4i. Now, it addition to removing the
complete garbage records which could sometimes be inserted by Valence 1.4h
in QWK network mode, it will optionally remove any member record which has
no correspoding user record. This can be useful for cleaning up after now-
deleted users, as well as fixing a QWK network problem.

The default behavior is to remove only the garbage; to do a complete purge,
add a "u" (or "-u", or "/u") on the command line. "SLMAIL" and "NETMAIL"
members will not be removed.

Basic garbage removal will get rid of any members whose names contain
lowercase characters, characters in the "low ASCII" range (0-31, plus 127
and 255), or characters in the "high ASCII" range (128-254) if the "Allow
High ASCII" flag is not set in CONFIG. (It's not, by default.) This takes
care of any names which contain untypable characters and will get the vast
bulk of the junk records.

NOTE: If you're upgrading from a version of Valence prior to 1.4m, and
you've been using Valence for QWK networking, DO NOT run Member Purge with
the /u parameter until after you've performed a network transfer! Versions
prior to 1.4m didn't create a Searchlight user record for the hub, so the
hub's pointers would be purged. The user file will be updated the first
time you run Valence 1.4m or higher in network mode.

Version 2.1 fixes a bug in 2.0 where, if the first member record in a
subboard were deleted, it could sometimes corrupt the member file.


:::: MAILLIST.EXE ::::

Mail List shows the From, To, and Subject lines for each message in the
MAIL subboard, in series. This is an offshoot of Mail Purge (in fact, it's
the same source code, with only a few lines changed or commented out). You
can get most of the same information by jumping to MAIL and scanning
forward, but not the To: field, which I needed to see while testing Mail
Purge. You may also find this more convenient than jumping to MAIL. The
output can be redirected, for processing by another program.


:::: MAILPURG.EXE ::::

Mail Purge removes stray messages from the MAIL subboard: messages which
are addressed to users who've been deleted, or who never existed on your
system. It ignores outbound netmail and Internet email, and checks every
other message against the user file and alias file for a valid recipient.
The From, To, and Subject fields of deleted messages will be displayed as
they're removed. (Messages which aren't removed won't be displayed; use
Mail List to see them.)

This program was prompted by a bug in Valence's QWK networking. (Perhaps I
should call it an oversight; I didn't expect anyone to receive messages in
conference 0 in a net-status packet.) But it can be useful on any
Searchlight system.


:::: ALIASBLD.EXE ::::

This program is only useful if you have Searchlight version 3.5A or higher.
It reads the alias names defined in the user file (USER.SL2), and creates a
new alias index (ALIAS.SL2) from them. You should only need to run it once,
but you can safely run it as often as you like. Its main purpose is to index
alias names which have been entered into user records, but not into the
alias file, by previous versions of Valence (or other programs). But it
should help with other reported problems with ALIAS.SL2; it builds a clean
file, from scratch, and avoids duplicates.

With the "-P" option, ALIASBLD will also remove any alias names from the
user records which are duplicates, or which duplicate a "real" name. This is
an option, rather than the default behavior, because it operates "first
come, first serve"; if two users have chosen the same alias, the one that
happens to come first in the user file gets to keep it. If an alias name
duplicates a real name, the real name always takes precedence.


:::: LICENSE AGREEMENT ::::

These programs are free software. You may make as many copies as you like,
and use them on as many machines simultaneously as you like, without paying
me anything, as long as you're not making any money off of it. Commercial
use requires a license. These programs may be freely distributed, provided
you charge no more than a minimal copying fee (say, $5.00). Distribution of
the programs at profit, or bundled with commercial software, requires a
license. The archive must be distributed unmodified, except for conversion
to another archive format or addition of ZIP/ARJ/etc. comments. No files
may be added within the archive, and none of the files within the archive
may be removed or modified.


:::: HISTORY ::::

1.3 - 2014/04/28:

- Updated addresses yet again; minor doc changes.

1.2 - 2005/01/14:

- Updated Internet addresses again.

1.1 - 2003/06/13:

- Updated Internet addresses in documentation.

1.0 - 1999/02/01:

- First collected release. Previously these utilities were distributed
  separately, or (in some cases) with Valence.
