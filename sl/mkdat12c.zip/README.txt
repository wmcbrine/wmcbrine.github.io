             "Makedate" Date Fixer for Searchlight, version 1.2
                           http://wmcbrine.com/sl/

                             Copyright (c) 2003
                     William McBrine <wmcbrine@gmail.com>

             Written using the Searchlight Programmer's Library
              Portions Copyright (c) 1994 Searchlight Software


:::: MAKEDATE.EXE ::::

I wrote this program primarily to deal with Y2K bugs in SLMAIL.EXE and
NETMAIL.EXE (hereafter collectively referred to as "SLMAIL"), though I'd
been thinking about doing something like this anyway to ease the transition
from one version of Searchlight to another.

The problem is with the way dates with a year of 2000 or later are
represented in Searchlight -- this has changed in SL 5.x. In the new
system, the year 2000 is stored as 100. But SLMAIL fails to export messages
with such a year; and when importing, it stores the year as 0, which shows
up as "1900" in SL 5.x. (For more on this, see the section "Dates in
Searchlight".)

Makedate allows you to alter the dates in the Searchlight message base,
switching between the "old" and "new" formats at will. The switch is based
on a fixed window: When converting from new to old, any year greater than
100 has 100 subtracted; and when converting from old to new, any year less
than 80 has 100 added. This should suffice to keep SLMAIL running for
another 80 years. (Searchlight 5.x itself has other date problems,
however, starting in 2076.)

For exports, the procedure is as follows:

 makedate old subname
 slmail e subname -g wherever
 makedate new subname

where "subname" is the name of the conference, and the second line is just
an example. The "old" and "new" parameters may be abbreviated to "o" or
"n". The first invocation changes all dates to a form SLMAIL can recognize;
then you call SLMAIL as usual. The final invocation of makedate restores
the dates to the new format.

When importing, you would also use makedate afterwards:

 slmail i subname -g wherever
 makedate new subname

to avoid the appearance of "1900" in the message base.

Instead of specifying each conference separately, you can provide a list to
Makedate:

 makedate new @listfile

This is similar to SLMAIL's "@" file option, but in this case, the list
file is a plain text list of conferences, one per line, rather than a list
of commands. The standard Searchlight "MAIN.SUB"-type file may be used for
this purpose.

Aside from working around bugs in SLMAIL, Makedate could also be useful if
you're upgrading from an older version of Searchlight to 5.0 or later, and
have year-2000 dates in your message base.

Makedate will also work with older (< 5.0) versions of Searchlight, but in
that case, it will refuse to convert to the new format, since that format
is not well understood by those versions of SL. (The year 2000 would appear
as "100".) It will convert from the new format to the old, if you have some
reason to do that (e.g., downgrading your SL setup).


::: DATES IN SEARCHLIGHT ::::

The Searchlight internal date format uses one unsigned binary byte to
represent the year, as well as one byte each for the month and day. In
versions prior to 5.0, the year was stored as (year mod 100); that is (in
decimal terms), as the last two digits. 1999 is stored as 99, and 2000 will
be stored (and displayed) as 00.
   
In SL 5.0, the displayed year was changed to use four digits, and the
internal date was redefined as (year - 1900). Thus, the year 2000 will be
stored as 100. (For years between 1900 and 2000, the definitions are
equivalent.) This redefinition has value, because it allows the year value
to be unambiguous; but it also breaks some things, like the old version of
the strdate() function from the Searchlight Programmers' Library, which
will now show "100" for the year 2000. Furthermore, it limits the maximum
year value to 1900 + 255, or 2155; but before that, MSDOS itself will run
out of time, at the end of 2099.
   
The routine which displays the day of the week in Searchlight works by
comparing the date with a known day, via the datediff() function, and using
that value mod 7 as the index to a string array. The date it uses is
1-1-87. Unfortunately, the datediff() routine only returns a 16-bit signed
integer, which means that it breaks after 32767 days. Hence, in Searchlight
5.x, the day of the week shows up incorrectly after 9-17-2076. (It prints
things like "December" where it should say "Wed".) In earlier versions, it
breaks much sooner -- on 1-1-2000. Granted, this is purely a cosmetic
problem.
   
Most Y2K problems with SL 4.5 will be cosmetic; e.g., the day of the week
will be printed incorrectly.

In previous versions of the above text, I followed that with "However,
things will work more smoothly all around if you upgrade to SL 5.x before
the year 2000." I regretfully retract that statement, given the evident Y2K
bugs in SLMAIL -- which, ironically, should NOT affect SL 4.5 systems.


:::: LICENSE AGREEMENT ::::

This program is free software, now released under the GPL.  See "COPYING"
for terms.  However, note that the GPL does not cover the Searchlight
Programmer's Library.


:::: HISTORY ::::

1.2c - 2014/04/28:

- Updated addresses.

1.2b - 2005/01/14:

- Updated Internet addresses.

1.2  - 2003/06/23:

- Oops! The source code released with 1.1b couldn't actually be compiled, 
  because it contained references to units that were neither included, nor 
  part of the Searchlight Programmer's Library.

- Moved sublistinit() call out of onesub() so it's only called once, even
  when processing multiple conferences.

1.1b - 2003/06/13:

- Changed license, released source; updated Internet addresses.

1.1  - 2000/01/14:

- Added list file capability and documentation.

1.0  - 2000/01/13:

- First release. No docs. :-)
